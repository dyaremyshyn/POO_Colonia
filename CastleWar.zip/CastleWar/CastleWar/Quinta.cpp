#include "Quinta.h"

Quinta::Quinta(string n, int c): Edificio(n,c)
{
}

Quinta::~Quinta()
{
}
