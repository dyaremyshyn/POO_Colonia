#include "Walker.h"


#include "Walker.h"

Walker::Walker(string n, int cm, int cf) : Caracteristica(n, cm, cf) {}

Walker::~Walker()
{
}

void Walker::fazEfeito(Posicao *p, Ser *s)
{

}


