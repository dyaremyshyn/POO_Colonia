#include "Castelo.h"

Castelo::Castelo(string n, int c):Edificio(n,c)
{
}

Castelo::~Castelo()
{
}

void Castelo::fazEfeito()
{
}
