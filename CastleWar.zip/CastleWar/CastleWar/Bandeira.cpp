#include "Bandeira.h"

Bandeira::Bandeira(string n, int cm, int cf): Caracteristica(n, cm, cf){}

Bandeira::~Bandeira()
{
}


void Bandeira::fazEfeito(Posicao *p, Ser *s)
{
	
}
