#include "BuildSeeker.h"

BuildSeeker::BuildSeeker(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar)
{
}

BuildSeeker::~BuildSeeker()
{
}

void BuildSeeker::fazEfeito(int p, Ser * s)
{
}
