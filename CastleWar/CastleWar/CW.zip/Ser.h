#pragma once

#ifndef SER_H
#define	SER_H

#include "Libraries.h"
#include "Posicao.h"

class Ser;
class Edificio;
class Jogo;
class Caracteristica;
class Posicao;

class Ser {
	int pos;
	string nome;
	int custo;
	vector<Caracteristica*> caracteristicas;
	string bandeira;
	
	int saude;
	int maxSaude;
	int forca;
	int velocidade;
	int ataque;
	int defesa;
	
	bool castelo;

public:
	Ser(string n, vector<Caracteristica*>c);
	~Ser();

	string getNome();

	void setPos(int p);
	int getPos();

	void setSaude(int v);
	int getSaude();

	void setMaxSaude(int s);
	int getMaxSaude();

	void setDefesa(int d);
	int getDefesa();

	void setAtaque(int a);
	int getAtaque();

	void setVelocidade(int v);
	int getVelocidade();

	void setForca(int f);
	int getForca();

	vector<Caracteristica*> getCaracteristicas();

	void ganhaCaracteristas(Caracteristica *c);
	void calcularCusto();


	void mover();
	void efeitoCaracteristicas();


	boolean dentroCastelo();
	void setCastelo(bool c);
};
#endif	/* SER_H */