#include "HeatSeeker.h"

HeatSeeker::HeatSeeker(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar)
{
}

HeatSeeker::~HeatSeeker()
{
}

void HeatSeeker::fazEfeito(int p, Ser * s)
{
}
