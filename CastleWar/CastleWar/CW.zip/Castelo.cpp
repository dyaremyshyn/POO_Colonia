#include "Castelo.h"

Castelo::Castelo(string n, int c, int s, int d):Edificio(n,c,s,d)
{
}

Castelo::~Castelo()
{
}

void Castelo::fazEfeito()
{
}
