#include "SecondChance.h"

SecondChance::SecondChance(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar)
{
}

SecondChance::~SecondChance()
{
}

void SecondChance::fazEfeito(int p, Ser * s)
{
}
