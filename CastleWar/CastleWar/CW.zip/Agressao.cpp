#include "Agressao.h"


Agressao::Agressao(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar)
{
}

Agressao::~Agressao()
{
}

void Agressao::fazEfeito(int p, Ser * s)
{

}
