#include "Ecologico.h"

Ecologico::Ecologico(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar)
{
}

Ecologico::~Ecologico()
{
}

void Ecologico::fazEfeito(int p, Ser * s)
{
}
