#include "Quinta.h"

Quinta::Quinta(string n, int c,int s, int d): Edificio(n,c,s,d)
{

}

Quinta::~Quinta()
{
}

void Quinta::fazEfeito()
{
}


