#include "Walker.h"


#include "Walker.h"

Walker::Walker(string n, int cm, int cf,int idCar) : Caracteristica(n, cm, cf, idCar) {}

Walker::~Walker()
{
}

void Walker::fazEfeito(int p, Ser *s)
{

}


