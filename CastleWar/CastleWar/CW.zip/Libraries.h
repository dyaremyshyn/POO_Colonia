#pragma once
#ifndef LIBRARIES_H
#define LIBRARIES_H

#include <iostream>
#include <cstdlib>
#include <random>
#include <string>
#include <windows.h>
#include <cmath>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include <time.h>
#include <fstream> 
#include <regex>



#include "Configuracoes.h"
#include "Consola.h"
using namespace std;
#endif