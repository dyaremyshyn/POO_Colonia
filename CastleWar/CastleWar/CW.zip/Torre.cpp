#include "Torre.h"

Torre::Torre(string n, int c, int s, int d) :Edificio(n, c, s, d)
{
}

Torre::~Torre()
{
}

void Torre::fazEfeito()
{
	
}

