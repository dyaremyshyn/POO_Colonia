#include "Bandeira.h"

Bandeira::Bandeira(string n, int cm, int cf,int idCar): Caracteristica(n, cm, cf, idCar){}

Bandeira::~Bandeira()
{
}


void Bandeira::fazEfeito(int p, Ser *s)
{
	
}
